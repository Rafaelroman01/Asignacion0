from setuptools import setup

setup (name="Proyecto0", 
       version="1.0",
       descripcion="Nuestroprimerpaquete.", 
       autor="Ramon Roman", 
       author_email="rafaelroman01@gmail.com", 
       packages=["Proyecto0"])